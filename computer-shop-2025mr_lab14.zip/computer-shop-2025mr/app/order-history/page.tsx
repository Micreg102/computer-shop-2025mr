export default function OrderHistory() {

    return (
        <main>
            <h2>Strona: order-history </h2>
            <p>To jest zawartość strony.</p>
        </main>
    );
}