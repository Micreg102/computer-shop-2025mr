export default function About() {
    return (
        <main>
            <h2>Strona: About </h2>
            <p>To jest zawartość strony.</p>
        </main>
    );
}