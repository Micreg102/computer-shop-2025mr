# NextJS Labs of BackEnd Programming

## Lab 10

The aim of the lab is to prepare the environment for creating a full-stack Next.js application, learn the basics of this framework and become familiar with handling subpages (routes).